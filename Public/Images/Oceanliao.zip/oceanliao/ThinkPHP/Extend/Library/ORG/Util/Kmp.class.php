<?php

class  Kmp
{
	private $head;         //头指针
    private $tail;          //尾指针
    private $curelement;   //当前指针

    

    
     // property declaration
	public function Kmp()
	{
		echo '123';
	}
     public  $var  =  'a default value' ;

     // method declaration
     public function  displayVar () {
        echo  $this -> var ; 
    }
}
